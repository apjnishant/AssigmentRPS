using Microsoft.VisualStudio.TestTools.UnitTesting;
using RPS.Game.BusinessLayer;
using RPS.Game.BusinessLayer.Model;
using RPS.Game.UnitTest.MockObjects;

namespace RPS.Game.UnitTest
{
    [TestClass]
    public class RPSGameUnitTest
    {

        [TestMethod]
        public void WinTest()
        {
            RPSGame rps = new RPSGame();
            MockRPSGame mockRPS = new MockRPSGame()
            {
                Player1Option = Options.Scissors,
                Player2Option = Options.Paper,
                Player1Result = Result.Win,
                Player2Result = Result.Lose
            };

            var expectedResult = mockRPS;
            var actualResult = rps.PlayGameWithMultiPlayer(Options.Scissors, Options.Paper);

            Assert.AreEqual(expectedResult.Player1Result, actualResult.Player1Result);
            Assert.AreEqual(expectedResult.Player2Result, actualResult.Player2Result);
        }

        [TestMethod]
        public void LoseTest()
        {
            RPSGame rps = new RPSGame();
            MockRPSGame mockRPS = new MockRPSGame()
            {
                Player1Option = Options.Scissors,
                Player2Option = Options.Rock,
                Player1Result = Result.Lose,
                Player2Result = Result.Win
            };

            var expectedResult = mockRPS;
            var actualResult = rps.PlayGameWithMultiPlayer(Options.Scissors, Options.Rock);

            Assert.AreEqual(expectedResult.Player1Result, actualResult.Player1Result);
            Assert.AreEqual(expectedResult.Player2Result, actualResult.Player2Result);
        }

        [TestMethod]
        public void DrawTest()
        {
            RPSGame rps = new RPSGame();
            MockRPSGame mockRPS = new MockRPSGame()
            {
                Player1Option = Options.Paper,
                Player2Option = Options.Paper,
                Player1Result = Result.Draw,
                Player2Result = Result.Draw
            };

            var expectedResult = mockRPS;
            var actualResult = rps.PlayGameWithMultiPlayer(Options.Paper, Options.Paper);

            Assert.AreEqual(expectedResult.Player1Result, actualResult.Player1Result);
            Assert.AreEqual(expectedResult.Player2Result, actualResult.Player2Result);
        }
    }
}
