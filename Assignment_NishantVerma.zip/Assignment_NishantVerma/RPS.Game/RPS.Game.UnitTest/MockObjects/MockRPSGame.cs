﻿using RPS.Game.BusinessLayer;
using RPS.Game.BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace RPS.Game.UnitTest.MockObjects
{
    class MockRPSGame :IRPSGame
    {
		public Options Player1Option
		{
			get;
			set;
		}

		public Options Player2Option
		{
			get;
			set;
		}

		public Result Player1Result
		{
			get;
			set;
		}

		public Result Player2Result
		{
			get;
			set;
		}

		public RPSGame PlayGameWithComputer(Options player1Option)
		{
			throw new NotImplementedException();
		}
		public RPSGame PlayGameWithMultiPlayer(Options player1Option, Options player2Option)
		{ 
			throw new NotImplementedException(); 
		}
	}
}
