﻿using RPS.Game.BusinessLayer;
using RPS.Game.BusinessLayer.Model;
using System;

namespace RPS.Game.ConsoleApp
{
    class Program
    {
        private static RPSGame objRPSGame = new RPSGame();
        static void Main(string[] args)
        {
			int iOptionsCount = Enum.GetNames(typeof(Options)).Length;
			int iChoice = 0;
			bool input = false;
			while (iChoice != iOptionsCount)
			{
				Console.Clear();
				//Echo Options
				Console.WriteLine("--------------------------------------------");
				Console.WriteLine("-------- Play Game with Computer -----------");
				Console.WriteLine("----- CHoose any option from below list ----");

				foreach (int i in Enum.GetValues(typeof(Options)))
				{
					Console.WriteLine("\t " + i.ToString() + "." + Enum.GetName(typeof(Options), i));
				}
				Console.WriteLine("Enter your choice (0 to exit):  ");
				Console.WriteLine("--------------------------------------------");

				input = int.TryParse(Console.ReadLine(), out iChoice);

				
				if (input)
				{
					if (Enum.IsDefined(typeof(Options), iChoice))
					{
						RPSGame objPlayerResult = new RPSGame();
						objPlayerResult=objRPSGame.PlayGameWithComputer((Options) iChoice);

						Console.WriteLine("Player Option: {0}, Computer Option: {1}", objPlayerResult.Player1Option, objPlayerResult.Player2Option);
						Console.WriteLine("Game Result: {0}!", objPlayerResult.Player1Result);

						Console.WriteLine("Game Count: {0}", objPlayerResult.iRoundCount);
						Console.WriteLine("Player One(Human) Score: {0}, Player Two (Computer) Score: {1}", objPlayerResult.iPlayer1Score, objPlayerResult.iPlayer2Score);

						Console.Read();
					}
					else
					{
						if (iChoice != iOptionsCount)
						{
							errorMessage();
						}
						break;
					}
				}
				else
				{
					errorMessage();
				}
			}
		}

		private static void errorMessage()
		{
			Console.WriteLine("Wrong options entered");
		}
	}
}
