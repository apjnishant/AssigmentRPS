﻿using RPS.Game.BusinessLayer.Model;
using RPS.Game.BusinessLayer.RandomComputerPlayer;
using System;
using System.Collections.Generic;
using System.Text;

namespace RPS.Game.BusinessLayer
{
    public class RPSGame : IRPSGame
    {
        private ComputerPlayer objComputePlayer = new ComputerPlayer();
        public Options Player1Option { get; private set; }
        public Options Player2Option { get; private set; }
        public Result Player1Result { get; private set; }
        public Result Player2Result { get; private set; }
        public int iRoundCount { get; private set; }
        public int iPlayer1Score { get; private set; }
        public int iPlayer2Score { get; private set; }

        public RPSGame()
        {
        }

        public RPSGame PlayGameWithComputer(Options player1Option)
        {

            Player1Option = player1Option;
            Player2Option = objComputePlayer.GetRandomOption(player1Option);

            return StartGame();


        }
        //Unit Test Purpose
        public RPSGame PlayGameWithMultiPlayer(Options player1Option, Options player2Option)
        {
            Player1Option = player1Option;
            Player2Option = player2Option;

            return StartGame();
        }

        private RPSGame StartGame()
        {
            iRoundCount++;

            if (Player1Option == Player2Option)
            {
                Player1Result = Result.Draw;
                Player2Result = Result.Draw;
            }

            if (Player1Option == Options.Paper)
            {
                if (Player2Option == Options.Rock)
                {
                    Player1Result = Result.Win;
                    Player2Result = Result.Lose;
                    iPlayer1Score++;
                }
                if (Player2Option == Options.Scissors)
                {
                    Player1Result = Result.Lose;
                    Player2Result = Result.Win;
                    iPlayer2Score++;
                }
            }

            if (Player1Option == Options.Rock)
            {
                if (Player2Option == Options.Scissors)
                {
                    Player1Result = Result.Win;
                    Player2Result = Result.Lose;
                    iPlayer1Score++;
                }
                if (Player2Option == Options.Paper)
                {
                    Player1Result = Result.Lose;
                    Player2Result = Result.Win;
                    iPlayer2Score++;
                }
            }

            if (Player1Option == Options.Scissors)
            {
                if (Player2Option == Options.Paper)
                {
                    Player1Result = Result.Win;
                    Player2Result = Result.Lose;
                    iPlayer1Score++;
                }
                if (Player2Option == Options.Rock)
                {
                    Player1Result = Result.Lose;
                    Player2Result = Result.Win;
                    iPlayer2Score++;
                }
            }

            return this;
        }
        public void Reset()
        {
            iPlayer1Score = 0;
            iPlayer2Score = 0;
            iRoundCount = 0;
        }
    }
}
