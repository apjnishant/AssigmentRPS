﻿using RPS.Game.BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace RPS.Game.BusinessLayer
{
    public interface IRPSGame
    {
		RPSGame PlayGameWithComputer(Options player1Option);
		RPSGame PlayGameWithMultiPlayer(Options player1Option, Options player2Option);
		Options Player1Option { get;}
		Options Player2Option { get; }
		Result Player1Result { get; }
		Result Player2Result { get; }

	}
}
