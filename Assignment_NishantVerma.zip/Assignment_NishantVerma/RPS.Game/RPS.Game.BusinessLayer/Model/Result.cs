﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPS.Game.BusinessLayer.Model
{
	public enum Result
	{
		Draw=1,
		Win=2,
		Lose=3
	}
}
