﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPS.Game.BusinessLayer.Model
{
	public enum Options
	{
		Rock=1,
		Paper=2,
		Scissors=3
	}
}
