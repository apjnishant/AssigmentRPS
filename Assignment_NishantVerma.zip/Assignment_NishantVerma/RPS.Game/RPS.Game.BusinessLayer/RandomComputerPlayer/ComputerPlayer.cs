﻿using RPS.Game.BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace RPS.Game.BusinessLayer.RandomComputerPlayer
{
    public class ComputerPlayer : IComputerPlayer
    {
		private Random r = new Random();

		private int newOption()
		{
			return r.Next(0, 3);
		}

		public Options GetRandomOption(Options playerOption)
		{
			Options randomChoice = (Options)newOption();
			return randomChoice;
		}
	}
}
