﻿using RPS.Game.BusinessLayer.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace RPS.Game.BusinessLayer.RandomComputerPlayer
{
    public interface IComputerPlayer
    {
        Options GetRandomOption(Options choice);
    }
}
